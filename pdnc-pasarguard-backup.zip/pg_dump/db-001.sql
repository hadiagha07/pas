--
-- PostgreSQL database dump
--

\restrict WJEinpc3hsNFR3GuQBsXFfP14aUCuqT1BjYF6fTfqsR6p6glAJfRJe6IAZoaEDc

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.nodes DROP CONSTRAINT IF EXISTS nodes_ibfk_1;
ALTER TABLE IF EXISTS ONLY public.users_groups_association DROP CONSTRAINT IF EXISTS fk_users_groups_association_user_id_users;
ALTER TABLE IF EXISTS ONLY public.users_groups_association DROP CONSTRAINT IF EXISTS fk_users_groups_association_groups_id_groups;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_users_admin_id_admins;
ALTER TABLE IF EXISTS ONLY public.user_usage_logs DROP CONSTRAINT IF EXISTS fk_user_usage_logs_user_id_users;
ALTER TABLE IF EXISTS ONLY public.user_subscription_updates DROP CONSTRAINT IF EXISTS fk_user_subscription_updates_user_id_users;
ALTER TABLE IF EXISTS ONLY public.user_hwids DROP CONSTRAINT IF EXISTS fk_user_hwids_user_id_users;
ALTER TABLE IF EXISTS ONLY public.template_group_association DROP CONSTRAINT IF EXISTS fk_template_group_association_user_template_id_user_templates;
ALTER TABLE IF EXISTS ONLY public.template_group_association DROP CONSTRAINT IF EXISTS fk_template_group_association_group_id_groups;
ALTER TABLE IF EXISTS ONLY public.notification_reminders DROP CONSTRAINT IF EXISTS fk_notification_reminders_user_id_users;
ALTER TABLE IF EXISTS ONLY public.node_user_usages DROP CONSTRAINT IF EXISTS fk_node_user_usages_user_id_users;
ALTER TABLE IF EXISTS ONLY public.node_user_usages DROP CONSTRAINT IF EXISTS fk_node_user_usages_node_id_nodes;
ALTER TABLE IF EXISTS ONLY public.node_usages DROP CONSTRAINT IF EXISTS fk_node_usages_node_id_nodes;
ALTER TABLE IF EXISTS ONLY public.node_usage_reset_logs DROP CONSTRAINT IF EXISTS fk_node_usage_reset_logs_node_id_nodes;
ALTER TABLE IF EXISTS ONLY public.node_stats DROP CONSTRAINT IF EXISTS fk_node_stats_node_id_nodes;
ALTER TABLE IF EXISTS ONLY public.next_plans DROP CONSTRAINT IF EXISTS fk_next_plans_user_template_id_user_templates;
ALTER TABLE IF EXISTS ONLY public.next_plans DROP CONSTRAINT IF EXISTS fk_next_plans_user_id_users;
ALTER TABLE IF EXISTS ONLY public.inbounds_groups_association DROP CONSTRAINT IF EXISTS fk_inbounds_groups_association_inbound_id_inbounds;
ALTER TABLE IF EXISTS ONLY public.inbounds_groups_association DROP CONSTRAINT IF EXISTS fk_inbounds_groups_association_group_id_groups;
ALTER TABLE IF EXISTS ONLY public.hosts DROP CONSTRAINT IF EXISTS fk_hosts_inbound_tag_inbounds;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS fk_api_keys_admin_id_admins;
ALTER TABLE IF EXISTS ONLY public.admins DROP CONSTRAINT IF EXISTS fk_admins_role_id_admin_roles;
ALTER TABLE IF EXISTS ONLY public.admin_usage_logs DROP CONSTRAINT IF EXISTS fk_admin_usage_logs_admin_id_admins;
ALTER TABLE IF EXISTS ONLY public.admin_notification_reminders DROP CONSTRAINT IF EXISTS fk_admin_notification_reminders_admin_id_admins;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_user_usage_logs_user_id_reset_at;
DROP INDEX IF EXISTS public.ix_user_hwids_user_id;
DROP INDEX IF EXISTS public.ix_user_hwids_last_used_at;
DROP INDEX IF EXISTS public.ix_user_hwids_hwid;
DROP INDEX IF EXISTS public.ix_user_hwids_created_at;
DROP INDEX IF EXISTS public.ix_node_user_usages_user_id_created_at;
DROP INDEX IF EXISTS public.ix_node_user_usages_node_id_created_at;
DROP INDEX IF EXISTS public.ix_node_user_usages_created_at;
DROP INDEX IF EXISTS public.ix_node_usages_created_at;
DROP INDEX IF EXISTS public.ix_node_usage_reset_logs_node_id_created_at;
DROP INDEX IF EXISTS public.ix_next_plans_user_template_id;
DROP INDEX IF EXISTS public.ix_inbounds_tag;
DROP INDEX IF EXISTS public.ix_client_templates_template_type;
DROP INDEX IF EXISTS public.ix_api_keys_expire_date;
DROP INDEX IF EXISTS public.ix_api_keys_created_at;
DROP INDEX IF EXISTS public.ix_api_keys_admin_id;
DROP INDEX IF EXISTS public.ix_admins_username;
DROP INDEX IF EXISTS public.ix_admin_notification_reminders_admin_id_type;
DROP INDEX IF EXISTS public.idx_users_admin_status;
DROP INDEX IF EXISTS public.idx_users_admin_online;
DROP INDEX IF EXISTS public.idx_users_admin_created;
DROP INDEX IF EXISTS public.idx_user_subscription_updates_user_id;
ALTER TABLE IF EXISTS ONLY public.user_templates DROP CONSTRAINT IF EXISTS uq_user_templates_name;
ALTER TABLE IF EXISTS ONLY public.user_hwids DROP CONSTRAINT IF EXISTS uq_user_hwids_user_id;
ALTER TABLE IF EXISTS ONLY public.nodes DROP CONSTRAINT IF EXISTS uq_nodes_name;
ALTER TABLE IF EXISTS ONLY public.node_user_usages DROP CONSTRAINT IF EXISTS uq_node_user_usages_created_at;
ALTER TABLE IF EXISTS ONLY public.node_usages DROP CONSTRAINT IF EXISTS uq_node_usages_created_at;
ALTER TABLE IF EXISTS ONLY public.client_templates DROP CONSTRAINT IF EXISTS uq_client_templates_template_type;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS uq_api_keys_key_hash;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS uq_api_keys_admin_id;
ALTER TABLE IF EXISTS ONLY public.admin_roles DROP CONSTRAINT IF EXISTS uq_admin_roles_name;
ALTER TABLE IF EXISTS ONLY public.users_groups_association DROP CONSTRAINT IF EXISTS pk_users_groups_association;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users;
ALTER TABLE IF EXISTS ONLY public.user_usage_logs DROP CONSTRAINT IF EXISTS pk_user_usage_logs;
ALTER TABLE IF EXISTS ONLY public.user_templates DROP CONSTRAINT IF EXISTS pk_user_templates;
ALTER TABLE IF EXISTS ONLY public.user_subscription_updates DROP CONSTRAINT IF EXISTS pk_user_subscription_updates;
ALTER TABLE IF EXISTS ONLY public.user_hwids DROP CONSTRAINT IF EXISTS pk_user_hwids;
ALTER TABLE IF EXISTS ONLY public.temp_keys DROP CONSTRAINT IF EXISTS pk_temp_keys;
ALTER TABLE IF EXISTS ONLY public.system DROP CONSTRAINT IF EXISTS pk_system;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS pk_settings;
ALTER TABLE IF EXISTS ONLY public.notification_reminders DROP CONSTRAINT IF EXISTS pk_notification_reminders;
ALTER TABLE IF EXISTS ONLY public.nodes DROP CONSTRAINT IF EXISTS pk_nodes;
ALTER TABLE IF EXISTS ONLY public.node_user_usages DROP CONSTRAINT IF EXISTS pk_node_user_usages;
ALTER TABLE IF EXISTS ONLY public.node_usages DROP CONSTRAINT IF EXISTS pk_node_usages;
ALTER TABLE IF EXISTS ONLY public.node_usage_reset_logs DROP CONSTRAINT IF EXISTS pk_node_usage_reset_logs;
ALTER TABLE IF EXISTS ONLY public.node_stats DROP CONSTRAINT IF EXISTS pk_node_stats;
ALTER TABLE IF EXISTS ONLY public.next_plans DROP CONSTRAINT IF EXISTS pk_next_plans;
ALTER TABLE IF EXISTS ONLY public.jwt DROP CONSTRAINT IF EXISTS pk_jwt;
ALTER TABLE IF EXISTS ONLY public.inbounds_groups_association DROP CONSTRAINT IF EXISTS pk_inbounds_groups_association;
ALTER TABLE IF EXISTS ONLY public.inbounds DROP CONSTRAINT IF EXISTS pk_inbounds;
ALTER TABLE IF EXISTS ONLY public.hosts DROP CONSTRAINT IF EXISTS pk_hosts;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS pk_groups;
ALTER TABLE IF EXISTS ONLY public.core_configs DROP CONSTRAINT IF EXISTS pk_core_configs;
ALTER TABLE IF EXISTS ONLY public.client_templates DROP CONSTRAINT IF EXISTS pk_client_templates;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS pk_api_keys;
ALTER TABLE IF EXISTS ONLY public.admins DROP CONSTRAINT IF EXISTS pk_admins;
ALTER TABLE IF EXISTS ONLY public.admin_usage_logs DROP CONSTRAINT IF EXISTS pk_admin_usage_logs;
ALTER TABLE IF EXISTS ONLY public.admin_roles DROP CONSTRAINT IF EXISTS pk_admin_roles;
ALTER TABLE IF EXISTS ONLY public.admin_notification_reminders DROP CONSTRAINT IF EXISTS pk_admin_notification_reminders;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_usage_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_subscription_updates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_hwids ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.system ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification_reminders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.nodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.node_user_usages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.node_usages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.node_usage_reset_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.node_stats ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.next_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.jwt ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.inbounds ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hosts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.core_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.client_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.api_keys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admin_usage_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admin_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admin_notification_reminders ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users_groups_association;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_usage_logs_id_seq;
DROP TABLE IF EXISTS public.user_usage_logs;
DROP SEQUENCE IF EXISTS public.user_templates_id_seq;
DROP TABLE IF EXISTS public.user_templates;
DROP SEQUENCE IF EXISTS public.user_subscription_updates_id_seq;
DROP TABLE IF EXISTS public.user_subscription_updates;
DROP SEQUENCE IF EXISTS public.user_hwids_id_seq;
DROP TABLE IF EXISTS public.user_hwids;
DROP TABLE IF EXISTS public.template_group_association;
DROP TABLE IF EXISTS public.temp_keys;
DROP SEQUENCE IF EXISTS public.system_id_seq;
DROP TABLE IF EXISTS public.system;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.notification_reminders_id_seq;
DROP TABLE IF EXISTS public.notification_reminders;
DROP SEQUENCE IF EXISTS public.nodes_id_seq;
DROP TABLE IF EXISTS public.nodes;
DROP SEQUENCE IF EXISTS public.node_user_usages_id_seq;
DROP TABLE IF EXISTS public.node_user_usages;
DROP SEQUENCE IF EXISTS public.node_usages_id_seq;
DROP TABLE IF EXISTS public.node_usages;
DROP SEQUENCE IF EXISTS public.node_usage_reset_logs_id_seq;
DROP TABLE IF EXISTS public.node_usage_reset_logs;
DROP SEQUENCE IF EXISTS public.node_stats_id_seq;
DROP TABLE IF EXISTS public.node_stats;
DROP SEQUENCE IF EXISTS public.next_plans_id_seq;
DROP TABLE IF EXISTS public.next_plans;
DROP SEQUENCE IF EXISTS public.jwt_id_seq;
DROP TABLE IF EXISTS public.jwt;
DROP SEQUENCE IF EXISTS public.inbounds_id_seq;
DROP TABLE IF EXISTS public.inbounds_groups_association;
DROP TABLE IF EXISTS public.inbounds;
DROP SEQUENCE IF EXISTS public.hosts_id_seq;
DROP TABLE IF EXISTS public.hosts;
DROP SEQUENCE IF EXISTS public.groups_id_seq;
DROP TABLE IF EXISTS public.groups;
DROP SEQUENCE IF EXISTS public.core_configs_id_seq;
DROP TABLE IF EXISTS public.core_configs;
DROP SEQUENCE IF EXISTS public.client_templates_id_seq;
DROP TABLE IF EXISTS public.client_templates;
DROP SEQUENCE IF EXISTS public.api_keys_id_seq;
DROP TABLE IF EXISTS public.api_keys;
DROP TABLE IF EXISTS public.alembic_version;
DROP SEQUENCE IF EXISTS public.admins_id_seq;
DROP TABLE IF EXISTS public.admins;
DROP SEQUENCE IF EXISTS public.admin_usage_logs_id_seq;
DROP TABLE IF EXISTS public.admin_usage_logs;
DROP SEQUENCE IF EXISTS public.admin_roles_id_seq;
DROP TABLE IF EXISTS public.admin_roles;
DROP SEQUENCE IF EXISTS public.admin_notification_reminders_id_seq;
DROP TABLE IF EXISTS public.admin_notification_reminders;
DROP TYPE IF EXISTS public.userstatuscreate;
DROP TYPE IF EXISTS public.userstatus;
DROP TYPE IF EXISTS public.remindertype;
DROP TYPE IF EXISTS public.proxytypes;
DROP TYPE IF EXISTS public.proxyhostsecurity;
DROP TYPE IF EXISTS public.proxyhostfingerprint;
DROP TYPE IF EXISTS public.proxyhostalpn;
DROP TYPE IF EXISTS public.nodestatus;
DROP TYPE IF EXISTS public.nodeconnectiontype;
DROP TYPE IF EXISTS public.datalimitresetstrategy;
DROP TYPE IF EXISTS public.coretype;
DROP TYPE IF EXISTS public.apikeystatus;
DROP TYPE IF EXISTS public.adminstatus;
DROP EXTENSION IF EXISTS timescaledb;
--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: adminstatus; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.adminstatus AS ENUM (
    'active',
    'disabled',
    'limited'
);


ALTER TYPE public.adminstatus OWNER TO pasarguard;

--
-- Name: apikeystatus; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.apikeystatus AS ENUM (
    'active',
    'disabled'
);


ALTER TYPE public.apikeystatus OWNER TO pasarguard;

--
-- Name: coretype; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.coretype AS ENUM (
    'xray',
    'wg',
    'mtproto',
    'singbox'
);


ALTER TYPE public.coretype OWNER TO pasarguard;

--
-- Name: datalimitresetstrategy; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.datalimitresetstrategy AS ENUM (
    'no_reset',
    'day',
    'week',
    'month',
    'year'
);


ALTER TYPE public.datalimitresetstrategy OWNER TO pasarguard;

--
-- Name: nodeconnectiontype; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.nodeconnectiontype AS ENUM (
    'grpc',
    'rest'
);


ALTER TYPE public.nodeconnectiontype OWNER TO pasarguard;

--
-- Name: nodestatus; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.nodestatus AS ENUM (
    'connected',
    'connecting',
    'error',
    'disabled',
    'limited'
);


ALTER TYPE public.nodestatus OWNER TO pasarguard;

--
-- Name: proxyhostalpn; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.proxyhostalpn AS ENUM (
    'h3',
    'h3,h2',
    'h3,h2,http/1.1',
    'none',
    'h2',
    'http/1.1',
    'h2,http/1.1'
);


ALTER TYPE public.proxyhostalpn OWNER TO pasarguard;

--
-- Name: proxyhostfingerprint; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.proxyhostfingerprint AS ENUM (
    'none',
    'chrome',
    'firefox',
    'safari',
    'ios',
    'android',
    'edge',
    '360',
    'qq',
    'random',
    'randomized',
    'randomizednoalpn',
    'unsafe'
);


ALTER TYPE public.proxyhostfingerprint OWNER TO pasarguard;

--
-- Name: proxyhostsecurity; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.proxyhostsecurity AS ENUM (
    'inbound_default',
    'none',
    'tls'
);


ALTER TYPE public.proxyhostsecurity OWNER TO pasarguard;

--
-- Name: proxytypes; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.proxytypes AS ENUM (
    'VMess',
    'VLESS',
    'Trojan',
    'Shadowsocks'
);


ALTER TYPE public.proxytypes OWNER TO pasarguard;

--
-- Name: remindertype; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.remindertype AS ENUM (
    'expiration_date',
    'data_usage'
);


ALTER TYPE public.remindertype OWNER TO pasarguard;

--
-- Name: userstatus; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.userstatus AS ENUM (
    'active',
    'disabled',
    'limited',
    'expired',
    'on_hold'
);


ALTER TYPE public.userstatus OWNER TO pasarguard;

--
-- Name: userstatuscreate; Type: TYPE; Schema: public; Owner: pasarguard
--

CREATE TYPE public.userstatuscreate AS ENUM (
    'active',
    'on_hold'
);


ALTER TYPE public.userstatuscreate OWNER TO pasarguard;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_notification_reminders; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.admin_notification_reminders (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    admin_id bigint NOT NULL,
    type public.remindertype NOT NULL,
    threshold integer
);


ALTER TABLE public.admin_notification_reminders OWNER TO pasarguard;

--
-- Name: admin_notification_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.admin_notification_reminders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_notification_reminders_id_seq OWNER TO pasarguard;

--
-- Name: admin_notification_reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.admin_notification_reminders_id_seq OWNED BY public.admin_notification_reminders.id;


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.admin_roles (
    id bigint NOT NULL,
    name character varying(64) NOT NULL,
    is_owner boolean DEFAULT false NOT NULL,
    permissions jsonb NOT NULL,
    limits jsonb NOT NULL,
    features jsonb NOT NULL,
    access jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    disabled_when_limited boolean DEFAULT false NOT NULL,
    disconnect_users_when_limited boolean DEFAULT true NOT NULL,
    hwid json NOT NULL,
    disconnect_users_when_disabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.admin_roles OWNER TO pasarguard;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.admin_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_roles_id_seq OWNER TO pasarguard;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- Name: admin_usage_logs; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.admin_usage_logs (
    id bigint NOT NULL,
    admin_id bigint NOT NULL,
    used_traffic_at_reset bigint NOT NULL,
    reset_at timestamp with time zone NOT NULL
);


ALTER TABLE public.admin_usage_logs OWNER TO pasarguard;

--
-- Name: admin_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.admin_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_usage_logs_id_seq OWNER TO pasarguard;

--
-- Name: admin_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.admin_usage_logs_id_seq OWNED BY public.admin_usage_logs.id;


--
-- Name: admins; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    username character varying(34) NOT NULL,
    hashed_password character varying(128) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    password_reset_at timestamp with time zone,
    telegram_id bigint,
    discord_webhook character varying(1024),
    used_traffic bigint DEFAULT '0'::bigint NOT NULL,
    sub_template character varying(1024),
    sub_domain character varying(256),
    profile_title character varying(512),
    support_url character varying(1024),
    notification_enable jsonb,
    note character varying(500),
    role_id bigint NOT NULL,
    permission_overrides jsonb,
    status public.adminstatus DEFAULT 'active'::public.adminstatus NOT NULL,
    data_limit bigint,
    last_status_change timestamp with time zone,
    custom_variables json
);


ALTER TABLE public.admins OWNER TO pasarguard;

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admins_id_seq OWNER TO pasarguard;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO pasarguard;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.api_keys (
    id bigint NOT NULL,
    admin_id bigint NOT NULL,
    name character varying(128) NOT NULL,
    note character varying(512),
    key_hash character varying(128) NOT NULL,
    api_key_trimmed character varying(16) NOT NULL,
    permissions json NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expire_date timestamp with time zone,
    revoked_at timestamp with time zone,
    status public.apikeystatus DEFAULT 'active'::public.apikeystatus NOT NULL,
    inherit_permissions boolean DEFAULT true NOT NULL
);


ALTER TABLE public.api_keys OWNER TO pasarguard;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.api_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO pasarguard;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: client_templates; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.client_templates (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    template_type character varying(32) NOT NULL,
    content text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_system boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_templates OWNER TO pasarguard;

--
-- Name: client_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.client_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_templates_id_seq OWNER TO pasarguard;

--
-- Name: client_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.client_templates_id_seq OWNED BY public.client_templates.id;


--
-- Name: core_configs; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.core_configs (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    name character varying(256) NOT NULL,
    config json NOT NULL,
    exclude_inbound_tags character varying(2048),
    fallbacks_inbound_tags character varying(2048),
    type public.coretype DEFAULT 'xray'::public.coretype NOT NULL
);


ALTER TABLE public.core_configs OWNER TO pasarguard;

--
-- Name: core_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.core_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.core_configs_id_seq OWNER TO pasarguard;

--
-- Name: core_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.core_configs_id_seq OWNED BY public.core_configs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    name character varying(64) NOT NULL,
    is_disabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.groups OWNER TO pasarguard;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO pasarguard;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: hosts; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.hosts (
    id bigint NOT NULL,
    remark character varying(256) NOT NULL,
    address character varying(256) NOT NULL,
    port integer,
    inbound_tag character varying(256),
    sni character varying(1000),
    host character varying(1000),
    security public.proxyhostsecurity DEFAULT 'inbound_default'::public.proxyhostsecurity NOT NULL,
    fingerprint public.proxyhostfingerprint DEFAULT 'none'::public.proxyhostfingerprint NOT NULL,
    allowinsecure boolean,
    is_disabled boolean,
    path character varying(256),
    random_user_agent boolean DEFAULT false NOT NULL,
    alpn character varying(14) DEFAULT 'none'::public.proxyhostalpn,
    use_sni_as_host boolean DEFAULT false NOT NULL,
    priority integer NOT NULL,
    http_headers json,
    transport_settings json,
    mux_settings json,
    noise_settings json,
    fragment_settings json,
    status character varying(60) DEFAULT ''::character varying,
    ech_config_list character varying(512),
    vless_route character varying(4),
    pinned_peer_cert_sha256 character varying(128),
    verify_peer_cert_by_name character varying(1000),
    ech_query_strategy character varying(8),
    wireguard_overrides json,
    subscription_templates json,
    final_mask_settings json
);


ALTER TABLE public.hosts OWNER TO pasarguard;

--
-- Name: hosts_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.hosts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hosts_id_seq OWNER TO pasarguard;

--
-- Name: hosts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.hosts_id_seq OWNED BY public.hosts.id;


--
-- Name: inbounds; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.inbounds (
    id bigint NOT NULL,
    tag character varying(256) NOT NULL
);


ALTER TABLE public.inbounds OWNER TO pasarguard;

--
-- Name: inbounds_groups_association; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.inbounds_groups_association (
    inbound_id bigint NOT NULL,
    group_id bigint NOT NULL
);


ALTER TABLE public.inbounds_groups_association OWNER TO pasarguard;

--
-- Name: inbounds_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.inbounds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inbounds_id_seq OWNER TO pasarguard;

--
-- Name: inbounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.inbounds_id_seq OWNED BY public.inbounds.id;


--
-- Name: jwt; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.jwt (
    id integer NOT NULL,
    secret_key character varying(64) NOT NULL
);


ALTER TABLE public.jwt OWNER TO pasarguard;

--
-- Name: jwt_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.jwt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jwt_id_seq OWNER TO pasarguard;

--
-- Name: jwt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.jwt_id_seq OWNED BY public.jwt.id;


--
-- Name: next_plans; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.next_plans (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    data_limit bigint NOT NULL,
    expire integer,
    add_remaining_traffic boolean DEFAULT false NOT NULL,
    user_template_id bigint
);


ALTER TABLE public.next_plans OWNER TO pasarguard;

--
-- Name: next_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.next_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.next_plans_id_seq OWNER TO pasarguard;

--
-- Name: next_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.next_plans_id_seq OWNED BY public.next_plans.id;


--
-- Name: node_stats; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.node_stats (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    node_id bigint NOT NULL,
    mem_total bigint NOT NULL,
    mem_used bigint NOT NULL,
    cpu_cores integer NOT NULL,
    cpu_usage double precision NOT NULL,
    incoming_bandwidth_speed bigint NOT NULL,
    outgoing_bandwidth_speed bigint NOT NULL
);


ALTER TABLE public.node_stats OWNER TO pasarguard;

--
-- Name: node_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.node_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.node_stats_id_seq OWNER TO pasarguard;

--
-- Name: node_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.node_stats_id_seq OWNED BY public.node_stats.id;


--
-- Name: node_usage_reset_logs; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.node_usage_reset_logs (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    node_id bigint NOT NULL,
    uplink bigint NOT NULL,
    downlink bigint NOT NULL
);


ALTER TABLE public.node_usage_reset_logs OWNER TO pasarguard;

--
-- Name: node_usage_reset_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.node_usage_reset_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.node_usage_reset_logs_id_seq OWNER TO pasarguard;

--
-- Name: node_usage_reset_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.node_usage_reset_logs_id_seq OWNED BY public.node_usage_reset_logs.id;


--
-- Name: node_usages; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.node_usages (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    node_id bigint,
    uplink bigint NOT NULL,
    downlink bigint NOT NULL
);


ALTER TABLE public.node_usages OWNER TO pasarguard;

--
-- Name: node_usages_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.node_usages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.node_usages_id_seq OWNER TO pasarguard;

--
-- Name: node_usages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.node_usages_id_seq OWNED BY public.node_usages.id;


--
-- Name: node_user_usages; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.node_user_usages (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_id bigint NOT NULL,
    node_id bigint,
    used_traffic bigint NOT NULL
);


ALTER TABLE public.node_user_usages OWNER TO pasarguard;

--
-- Name: node_user_usages_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.node_user_usages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.node_user_usages_id_seq OWNER TO pasarguard;

--
-- Name: node_user_usages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.node_user_usages_id_seq OWNED BY public.node_user_usages.id;


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.nodes (
    id bigint NOT NULL,
    name character varying(256) NOT NULL,
    address character varying(256) NOT NULL,
    port integer NOT NULL,
    status public.nodestatus NOT NULL,
    last_status_change timestamp with time zone,
    message character varying(1024),
    created_at timestamp with time zone NOT NULL,
    uplink bigint NOT NULL,
    downlink bigint NOT NULL,
    xray_version character varying(32),
    usage_coefficient double precision DEFAULT 1.0 NOT NULL,
    node_version character varying(32),
    connection_type public.nodeconnectiontype DEFAULT 'grpc'::public.nodeconnectiontype NOT NULL,
    server_ca character varying(2048) DEFAULT ''::character varying NOT NULL,
    keep_alive integer DEFAULT 0 NOT NULL,
    core_config_id bigint,
    api_key character varying(36),
    data_limit bigint DEFAULT 0 NOT NULL,
    data_limit_reset_strategy public.datalimitresetstrategy DEFAULT 'no_reset'::public.datalimitresetstrategy NOT NULL,
    reset_time integer DEFAULT '-1'::integer NOT NULL,
    default_timeout integer DEFAULT 10 NOT NULL,
    internal_timeout integer DEFAULT 15 NOT NULL,
    api_port integer DEFAULT 62051 NOT NULL,
    proxy_url character varying(256)
);


ALTER TABLE public.nodes OWNER TO pasarguard;

--
-- Name: nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nodes_id_seq OWNER TO pasarguard;

--
-- Name: nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.nodes_id_seq OWNED BY public.nodes.id;


--
-- Name: notification_reminders; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.notification_reminders (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type public.remindertype NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    threshold integer
);


ALTER TABLE public.notification_reminders OWNER TO pasarguard;

--
-- Name: notification_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.notification_reminders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_reminders_id_seq OWNER TO pasarguard;

--
-- Name: notification_reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.notification_reminders_id_seq OWNED BY public.notification_reminders.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    telegram json NOT NULL,
    webhook json NOT NULL,
    notification_settings json NOT NULL,
    notification_enable json NOT NULL,
    subscription json NOT NULL,
    general json NOT NULL,
    hwid json NOT NULL
);


ALTER TABLE public.settings OWNER TO pasarguard;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO pasarguard;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: system; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.system (
    id bigint NOT NULL,
    uplink bigint NOT NULL,
    downlink bigint NOT NULL
);


ALTER TABLE public.system OWNER TO pasarguard;

--
-- Name: system_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.system_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_id_seq OWNER TO pasarguard;

--
-- Name: system_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.system_id_seq OWNED BY public.system.id;


--
-- Name: temp_keys; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.temp_keys (
    key character varying(36) NOT NULL,
    action character varying(32) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    used_by_ip character varying(45)
);


ALTER TABLE public.temp_keys OWNER TO pasarguard;

--
-- Name: template_group_association; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.template_group_association (
    user_template_id bigint,
    group_id bigint
);


ALTER TABLE public.template_group_association OWNER TO pasarguard;

--
-- Name: user_hwids; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.user_hwids (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    hwid character varying(256) NOT NULL,
    device_os character varying(256),
    os_version character varying(128),
    device_model character varying(256),
    created_at timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_hwids OWNER TO pasarguard;

--
-- Name: user_hwids_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.user_hwids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_hwids_id_seq OWNER TO pasarguard;

--
-- Name: user_hwids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.user_hwids_id_seq OWNED BY public.user_hwids.id;


--
-- Name: user_subscription_updates; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.user_subscription_updates (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_agent character varying(512) NOT NULL,
    ip character varying(64),
    hwid character varying(256)
);


ALTER TABLE public.user_subscription_updates OWNER TO pasarguard;

--
-- Name: user_subscription_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.user_subscription_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_subscription_updates_id_seq OWNER TO pasarguard;

--
-- Name: user_subscription_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.user_subscription_updates_id_seq OWNED BY public.user_subscription_updates.id;


--
-- Name: user_templates; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.user_templates (
    id bigint NOT NULL,
    name character varying(64) NOT NULL,
    data_limit bigint NOT NULL,
    expire_duration bigint NOT NULL,
    username_prefix character varying(20),
    username_suffix character varying(20),
    extra_settings json,
    status public.userstatuscreate DEFAULT 'active'::public.userstatuscreate NOT NULL,
    reset_usages boolean DEFAULT false NOT NULL,
    on_hold_timeout integer,
    data_limit_reset_strategy public.datalimitresetstrategy DEFAULT 'no_reset'::public.datalimitresetstrategy NOT NULL,
    is_disabled boolean DEFAULT false NOT NULL,
    hwid_limit bigint
);


ALTER TABLE public.user_templates OWNER TO pasarguard;

--
-- Name: user_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.user_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_templates_id_seq OWNER TO pasarguard;

--
-- Name: user_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.user_templates_id_seq OWNED BY public.user_templates.id;


--
-- Name: user_usage_logs; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.user_usage_logs (
    id bigint NOT NULL,
    user_id bigint,
    used_traffic_at_reset bigint NOT NULL,
    reset_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_usage_logs OWNER TO pasarguard;

--
-- Name: user_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.user_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_usage_logs_id_seq OWNER TO pasarguard;

--
-- Name: user_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.user_usage_logs_id_seq OWNED BY public.user_usage_logs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(128) NOT NULL COLLATE pg_catalog."C",
    status public.userstatus NOT NULL,
    used_traffic bigint NOT NULL,
    data_limit bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    admin_id bigint,
    data_limit_reset_strategy public.datalimitresetstrategy DEFAULT 'no_reset'::public.datalimitresetstrategy NOT NULL,
    sub_revoked_at timestamp with time zone,
    note character varying(500),
    online_at timestamp with time zone,
    edit_at timestamp with time zone,
    on_hold_timeout timestamp with time zone,
    on_hold_expire_duration bigint,
    auto_delete_in_days integer,
    last_status_change timestamp with time zone,
    expire timestamp with time zone,
    proxy_settings json DEFAULT '{}'::jsonb NOT NULL,
    hwid_limit bigint
);


ALTER TABLE public.users OWNER TO pasarguard;

--
-- Name: users_groups_association; Type: TABLE; Schema: public; Owner: pasarguard
--

CREATE TABLE public.users_groups_association (
    user_id bigint NOT NULL,
    groups_id bigint NOT NULL
);


ALTER TABLE public.users_groups_association OWNER TO pasarguard;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: pasarguard
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO pasarguard;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pasarguard
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admin_notification_reminders id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_notification_reminders ALTER COLUMN id SET DEFAULT nextval('public.admin_notification_reminders_id_seq'::regclass);


--
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- Name: admin_usage_logs id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.admin_usage_logs_id_seq'::regclass);


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: client_templates id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.client_templates ALTER COLUMN id SET DEFAULT nextval('public.client_templates_id_seq'::regclass);


--
-- Name: core_configs id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.core_configs ALTER COLUMN id SET DEFAULT nextval('public.core_configs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: hosts id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.hosts ALTER COLUMN id SET DEFAULT nextval('public.hosts_id_seq'::regclass);


--
-- Name: inbounds id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.inbounds ALTER COLUMN id SET DEFAULT nextval('public.inbounds_id_seq'::regclass);


--
-- Name: jwt id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.jwt ALTER COLUMN id SET DEFAULT nextval('public.jwt_id_seq'::regclass);


--
-- Name: next_plans id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.next_plans ALTER COLUMN id SET DEFAULT nextval('public.next_plans_id_seq'::regclass);


--
-- Name: node_stats id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_stats ALTER COLUMN id SET DEFAULT nextval('public.node_stats_id_seq'::regclass);


--
-- Name: node_usage_reset_logs id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usage_reset_logs ALTER COLUMN id SET DEFAULT nextval('public.node_usage_reset_logs_id_seq'::regclass);


--
-- Name: node_usages id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usages ALTER COLUMN id SET DEFAULT nextval('public.node_usages_id_seq'::regclass);


--
-- Name: node_user_usages id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_user_usages ALTER COLUMN id SET DEFAULT nextval('public.node_user_usages_id_seq'::regclass);


--
-- Name: nodes id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.nodes ALTER COLUMN id SET DEFAULT nextval('public.nodes_id_seq'::regclass);


--
-- Name: notification_reminders id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.notification_reminders ALTER COLUMN id SET DEFAULT nextval('public.notification_reminders_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: system id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.system ALTER COLUMN id SET DEFAULT nextval('public.system_id_seq'::regclass);


--
-- Name: user_hwids id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_hwids ALTER COLUMN id SET DEFAULT nextval('public.user_hwids_id_seq'::regclass);


--
-- Name: user_subscription_updates id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_subscription_updates ALTER COLUMN id SET DEFAULT nextval('public.user_subscription_updates_id_seq'::regclass);


--
-- Name: user_templates id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_templates ALTER COLUMN id SET DEFAULT nextval('public.user_templates_id_seq'::regclass);


--
-- Name: user_usage_logs id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.user_usage_logs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, schema_change_timestamp) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_jobs_refresh_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_jobs_refresh_ranges (materialization_id, start_range, end_range, pid, job_id, created_at) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.dimension_slice (id, chunk_id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-07-22 04:38:47.308016+00	t
timescaledb_version	2.28.3	f
exported_uuid	36ec4046-b1f4-494c-9282-bc3a9f1e4815	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: pasarguard
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: admin_notification_reminders; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.admin_notification_reminders (id, created_at, admin_id, type, threshold) FROM stdin;
\.


--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.admin_roles (id, name, is_owner, permissions, limits, features, access, created_at, disabled_when_limited, disconnect_users_when_limited, hwid, disconnect_users_when_disabled) FROM stdin;
2	administrator	f	{"cores": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "hosts": {"read": true, "create": true, "update": true}, "hwids": {"read": true, "delete": true}, "nodes": {"logs": true, "read": true, "stats": true, "create": true, "delete": true, "update": true, "reconnect": true, "read_simple": true, "update_core": true}, "users": {"read": {"scope": 2}, "create": true, "delete": {"scope": 2}, "update": {"scope": 2}, "set_owner": true, "revoke_sub": {"scope": 2}, "read_simple": {"scope": 2}, "reset_usage": {"scope": 2}, "activate_next_plan": {"scope": 2}}, "admins": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true, "reset_usage": true}, "groups": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "system": {"read": true}, "api_keys": {"read": {"scope": 2}, "create": true, "delete": {"scope": 2}, "update": {"scope": 2}, "read_simple": {"scope": 2}}, "settings": {"read": true, "update": true, "read_general": true}, "templates": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "admin_roles": {"read": true, "read_simple": true}, "client_templates": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}}	{"max_users": null, "expire_max": null, "expire_min": null, "data_limit_max": null, "data_limit_min": null, "max_hwid_per_user": null, "min_hwid_per_user": null}	{"can_use_next_plan": true, "can_use_reset_strategy": true}	{"require_template": false, "allowed_group_ids": null, "allowed_template_ids": null}	2026-07-22 04:39:10.178043+00	f	t	{"mode": "use_global", "forced": false, "enabled": true, "max_limit": null, "min_limit": null, "fallback_limit": null}	t
1	owner	t	{"cores": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "hosts": {"read": true, "create": true, "update": true}, "hwids": {"read": true, "delete": true}, "nodes": {"logs": true, "read": true, "stats": true, "create": true, "delete": true, "update": true, "reconnect": true, "read_simple": true, "update_core": true}, "users": {"read": {"scope": 2}, "create": true, "delete": {"scope": 2}, "update": {"scope": 2}, "set_owner": true, "revoke_sub": {"scope": 2}, "read_simple": {"scope": 2}, "reset_usage": {"scope": 2}, "activate_next_plan": {"scope": 2}}, "admins": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true, "reset_usage": true}, "groups": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "system": {"read": true}, "api_keys": {"read": {"scope": 2}, "create": true, "delete": {"scope": 2}, "update": {"scope": 2}, "read_simple": {"scope": 2}}, "settings": {"read": true, "update": true, "read_general": true}, "templates": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "admin_roles": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}, "client_templates": {"read": true, "create": true, "delete": true, "update": true, "read_simple": true}}	{"max_users": null, "expire_max": null, "expire_min": null, "data_limit_max": null, "data_limit_min": null, "max_hwid_per_user": null, "min_hwid_per_user": null}	{"can_use_next_plan": true, "can_use_reset_strategy": true}	{"require_template": false, "allowed_group_ids": null, "allowed_template_ids": null}	2026-07-22 04:39:10.178043+00	f	t	{"mode": "use_global", "forced": false, "enabled": true, "max_limit": null, "min_limit": null, "fallback_limit": null}	t
3	operator	f	{"hwids": {"read": true, "delete": true}, "users": {"read": {"scope": 1}, "create": true, "delete": {"scope": 1}, "update": {"scope": 1}, "set_owner": null, "revoke_sub": {"scope": 1}, "read_simple": {"scope": 1}, "reset_usage": {"scope": 1}, "activate_next_plan": {"scope": 1}}, "groups": {"read": false, "create": false, "delete": false, "update": false, "read_simple": true}, "system": {"read": true}, "api_keys": {"read": {"scope": 1}, "delete": {"scope": 1}, "update": {"scope": 1}, "read_simple": {"scope": 1}}, "settings": {"read": false, "update": false, "read_general": true}, "templates": {"read": true, "create": false, "delete": false, "update": false, "read_simple": true}}	{"max_users": null, "expire_max": null, "expire_min": null, "data_limit_max": null, "data_limit_min": null, "max_hwid_per_user": null, "min_hwid_per_user": null}	{"can_use_next_plan": true, "can_use_reset_strategy": true}	{"require_template": false, "allowed_group_ids": null, "allowed_template_ids": null}	2026-07-22 04:39:10.178043+00	f	t	{"mode": "use_global", "forced": false, "enabled": true, "max_limit": null, "min_limit": null, "fallback_limit": null}	t
\.


--
-- Data for Name: admin_usage_logs; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.admin_usage_logs (id, admin_id, used_traffic_at_reset, reset_at) FROM stdin;
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.admins (id, username, hashed_password, created_at, password_reset_at, telegram_id, discord_webhook, used_traffic, sub_template, sub_domain, profile_title, support_url, notification_enable, note, role_id, permission_overrides, status, data_limit, last_status_change, custom_variables) FROM stdin;
1	admin	$2b$12$8QHEy5GxRaUYQB9ufLXvYu9zvepD4cA9nle24GRrzFO/Whk/4o2Hu	2026-07-22 04:41:29.839337+00	\N	\N	\N	59262175	\N	\N	\N	\N	\N	\N	1	\N	active	\N	\N	\N
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.alembic_version (version_num) FROM stdin;
f976bfcf4738
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.api_keys (id, admin_id, name, note, key_hash, api_key_trimmed, permissions, created_at, expire_date, revoked_at, status, inherit_permissions) FROM stdin;
\.


--
-- Data for Name: client_templates; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.client_templates (id, name, template_type, content, is_default, is_system) FROM stdin;
1	Default Clash Subscription	clash_subscription	mode: rule\nmixed-port: 7890\nipv6: true\n\ntun:\n  enable: true\n  stack: mixed\n  dns-hijack:\n    - "any:53"\n  auto-route: true\n  auto-detect-interface: true\n  strict-route: true\n\ndns:\n  enable: true\n  listen: :1053\n  ipv6: true\n  nameserver:\n    - 'https://1.1.1.1/dns-query#PROXY'\n  proxy-server-nameserver:\n    - '8.8.8.8'\n    - '1.1.1.1'\n\nsniffer:\n  enable: true\n  override-destination: true\n  sniff:\n    HTTP:\n      ports: [80, 8080-8880]\n    TLS:\n      ports: [443, 8443]\n    QUIC:\n      ports: [443, 8443]\n\n{{ conf | except("proxy-groups", "port", "mode", "rules") | yaml }}\n\nproxy-groups:\n- name: 'PROXY'\n  type: 'select'\n  proxies:\n  - 'Fastest'\n  {{ proxy_remarks | yaml | indent(2) }}\n\n- name: 'Fastest'\n  type: 'url-test'\n  proxies:\n  {{ proxy_remarks | yaml | indent(2) }}\n\nrules:\n  - MATCH,PROXY	t	t
2	Default Xray Subscription	xray_subscription	{\n  "log": {\n    "access": "",\n    "error": "",\n    "loglevel": "warning"\n  },\n "policy": {\n    "system": {\n        "statsOutboundDownlink": true,\n        "statsOutboundUplink": true\n    },\n\t"levels": {\n     "8": {\n       "connIdle": 300,\n       "downlinkOnly": 1,\n       "handshake": 4,\n       "uplinkOnly": 1\n     }\n   }\n   },\n  "inbounds": [\n    {\n      "tag": "socks",\n      "port": 10808,\n      "listen": "0.0.0.0",\n      "protocol": "socks",\n      "sniffing": {\n        "enabled": true,\n        "destOverride": [\n          "http",\n          "tls"\n        ],\n        "routeOnly": false\n      },\n      "settings": {\n        "auth": "noauth",\n        "udp": true,\n        "allowTransparent": false\n      }\n    },\n    {\n      "tag": "http",\n      "port": 10809,\n      "listen": "0.0.0.0",\n      "protocol": "http",\n      "sniffing": {\n        "enabled": true,\n        "destOverride": [\n          "http",\n          "tls"\n        ],\n        "routeOnly": false\n      },\n      "settings": {\n        "auth": "noauth",\n        "udp": true,\n        "allowTransparent": false\n      }\n    }\n  ],\n  "outbounds": [\n      {\n        "protocol": "freedom",\n        "tag": "DIRECT"\n      },\n      {\n        "protocol": "blackhole",\n        "tag": "BLOCK"\n      }\n    ],\n  "dns": {\n    "servers": [\n      "1.1.1.1",\n      "8.8.8.8"\n    ]\n  },\n  "routing": {\n    "domainStrategy": "AsIs",\n    "rules": []\n  }\n}	t	t
3	Default Singbox Subscription	singbox_subscription	{\n  "log": {\n    "level": "warn",\n    "timestamp": false\n  },\n  "dns": {\n    "servers": [\n      {\n        "type": "udp",\n        "tag": "dns-remote",\n        "server": "1.1.1.2",\n        "detour": "proxy"\n      },\n      {\n        "type": "local",\n        "tag": "dns-local"\n      }\n    ],\n    "final": "dns-remote"\n  },\n  "inbounds": [\n    {\n      "type": "tun",\n      "tag": "tun-in",\n      "interface_name": "sing-tun",\n      "address": [\n        "172.19.0.1/30",\n        "fdfe:dcba:9876::1/126"\n      ],\n      "auto_route": true,\n      "route_exclude_address": [\n        "192.168.0.0/16",\n        "10.0.0.0/8",\n        "169.254.0.0/16",\n        "172.16.0.0/12",\n        "fe80::/10",\n        "fc00::/7"\n      ]\n    }\n  ],\n  "outbounds": [\n    {\n      "type": "selector",\n      "tag": "proxy",\n      "outbounds": null,\n      "interrupt_exist_connections": true\n    },\n    {\n      "type": "urltest",\n      "tag": "Best Latency",\n      "outbounds": null\n    },\n    {\n      "type": "direct",\n      "tag": "direct"\n    }\n  ],\n  "route": {\n    "rules": [\n      {\n        "inbound": "tun-in",\n        "action": "sniff"\n      },\n      {\n        "protocol": "dns",\n        "action": "hijack-dns"\n      }\n    ],\n    "final": "proxy",\n    "auto_detect_interface": true,\n    "override_android_vpn": true\n  },\n  "experimental": {\n    "cache_file": {\n      "enabled": true,\n      "store_dns": true\n    }\n  }\n}	t	t
4	Default User-Agent Template	user_agent	{\n  "list":[\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 PageSpeedPlus/1.0.0",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 11.6; rv:92.0) Gecko/20100101 Firefox/92.0",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.4.14 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:126.0) Gecko/20100101 Firefox/126.0",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:125.0) Gecko/20100101 Firefox/125.0",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.4.16 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.5.3 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2.1 Safari/605.1.15",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.5.12 Chrome/120.0.6099.283 Electron/28.2.3 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.4.16 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 OPR/109.0.0.0",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.15",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.4.13 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",\n    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.4.13 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Safari/605.1.15",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.1 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.5.12 Chrome/120.0.6099.283 Electron/28.2.3 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Safari/605.1.15",\n    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.2 Mobile/15E148 Safari/604.1",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:124.0) Gecko/20100101 Firefox/124.0",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) obsidian/1.5.3 Chrome/114.0.5735.289 Electron/25.8.1 Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",\n    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",\n    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/24.0 Chrome/117.0.0.0 Mobile Safari/537.36"\n  ]\n}	t	t
5	Default gRPC User-Agent Template	grpc_user_agent	{\n    "list": [\n        "grpc-dotnet/2.41.0 (.NET 6.0.1; CLR 6.0.1; net6.0; windows; x64)",\n        "grpc-dotnet/2.41.0 (.NET 6.0.0-preview.7.21377.19; CLR 6.0.0; net6.0; osx; x64)",\n        "grpc-dotnet/2.41.0 (Mono 6.12.0.140; CLR 4.0.30319; netstandard2.0; osx; x64)",\n        "grpc-dotnet/2.41.0 (.NET 6.0.0-rc.1.21380.1; CLR 6.0.0; net6.0; linux; arm64)",\n        "grpc-dotnet/2.41.0 (.NET 5.0.8; CLR 5.0.8; net5.0; linux; arm64)",\n        "grpc-dotnet/2.41.0 (.NET Core; CLR 3.1.4; netstandard2.1; linux; arm64)",\n        "grpc-dotnet/2.41.0 (.NET Framework; CLR 4.0.30319.42000; netstandard2.0; windows; x86)",\n        "grpc-dotnet/2.41.0 (.NET 6.0.0-rc.1.21380.1; CLR 6.0.0; net6.0; windows; x64)",\n        "grpc-python-asyncio/1.62.1 grpc-c/39.0.0 (linux; chttp2)",\n        "grpc-go/1.58.1",\n        "grpc-java-okhttp/1.55.1",\n        "grpc-node/1.7.1 grpc-c/1.7.1 (osx; chttp2)",\n        "grpc-node/1.24.2 grpc-c/8.0.0 (linux; chttp2; ganges)",\n        "grpc-c++/1.16.0 grpc-c/6.0.0 (linux; nghttp2; hw)",\n        "grpc-node/1.19.0 grpc-c/7.0.0 (linux; chttp2; gold)",\n        "grpc-ruby/1.62.0 grpc-c/39.0.0 (osx; chttp2)]"\n    ]\n}	t	t
\.


--
-- Data for Name: core_configs; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.core_configs (id, created_at, name, config, exclude_inbound_tags, fallbacks_inbound_tags, type) FROM stdin;
1	2026-07-22 04:39:08.791095+00	Default Core Config	{"policy": {"levels": {"0": {"statsUserOnline": true}}}, "burstObservatory": {"subjectSelector": ["DIRECT"], "pingConfig": {"destination": "https://www.google.com/generate_204", "connectivity": "https://www.google.com/generate_204", "interval": "1m", "sampling": 10, "timeout": "5s", "httpMethod": "HEAD"}}, "log": {"loglevel": "info"}, "inbounds": [{"tag": "Shadowsocks TCP", "port": 1080, "protocol": "shadowsocks", "settings": {"clients": [], "network": "tcp,udp"}, "streamSettings": {"network": "tcp", "security": "none", "tcpSettings": {}}}, {"tag": "VLESS WS TLS 8443", "port": 8443, "protocol": "vless", "settings": {"clients": [], "decryption": "mlkem768x25519plus.native.600s.RX0Dg9AWBLrMOeqGY1enQjIasFOJTzcj0eoW6awZTAA", "encryption": "mlkem768x25519plus.native.0rtt.5R8Y8x-7s33Tf6M0tkjNUayqL79JnmsYF-Yh4UI6uWw"}, "streamSettings": {"network": "ws", "security": "tls", "tlsSettings": {"serverName": "pdnc.blackoc.ir", "alpn": ["h3", "h2", "http/1.1"], "certificates": [{"certificate": ["-----BEGIN CERTIFICATE-----", "MIIBuTCCAV+gAwIBAgIUTn24coKlW7k6Yo7JuKk9zgNBxsMwCgYIKoZIzj0EAwIw", "FzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMB4XDTI2MDcyMjA0NDAyMloXDTM2MDcx", "OTA0NDAyMlowFzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMFkwEwYHKoZIzj0CAQYI", "KoZIzj0DAQcDQgAEghiuAAB3mtY7RtTp7JrPaodf+G6wCetaVD3jNz1/zkJWLyTD", "Tq8DhE6Qso3Phq3qm1l3/9VKV0WdakvV2+0ZKKOBiDCBhTAdBgNVHQ4EFgQUEatT", "bmmWsV87I0JJXHjr+EFUG+IwHwYDVR0jBBgwFoAUEatTbmmWsV87I0JJXHjr+EFU", "G+IwDwYDVR0TAQH/BAUwAwEB/zAyBgNVHREEKzApgglsb2NhbGhvc3SHBH8AAAGH", "ECoBBPjAEH55AAAAAAAAAAGHBFtrpgAwCgYIKoZIzj0EAwIDSAAwRQIhAJZcPG0L", "hrNsdu/Bza0FHk8bWTOji4l7642nkK2QU7mxAiAJSRcNwFKxLu4B7rkky78gQApp", "rqges/DNkDJYhqNA8w==", "-----END CERTIFICATE-----"], "key": ["-----BEGIN PRIVATE KEY-----", "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQggBHazYIFttfoJwa9", "lwqQ2TvfqVulci4hUMg/LkozVTOhRANCAASCGK4AAHea1jtG1Onsms9qh1/4brAJ", "61pUPeM3PX/OQlYvJMNOrwOETpCyjc+GreqbWXf/1UpXRZ1qS9Xb7Rko", "-----END PRIVATE KEY-----"], "serveOnNode": false}]}, "wsSettings": {"path": "/", "host": "pdnc.blackoc.ir"}}}, {"tag": "VLESS WS TLS 2087", "port": 2087, "protocol": "vless", "settings": {"clients": [], "decryption": "none"}, "streamSettings": {"network": "ws", "security": "tls", "tlsSettings": {"serverName": "pdnc.blackoc.ir", "alpn": ["h3", "h2", "http/1.1"], "certificates": [{"certificate": ["-----BEGIN CERTIFICATE-----", "MIIBuTCCAV+gAwIBAgIUTn24coKlW7k6Yo7JuKk9zgNBxsMwCgYIKoZIzj0EAwIw", "FzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMB4XDTI2MDcyMjA0NDAyMloXDTM2MDcx", "OTA0NDAyMlowFzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMFkwEwYHKoZIzj0CAQYI", "KoZIzj0DAQcDQgAEghiuAAB3mtY7RtTp7JrPaodf+G6wCetaVD3jNz1/zkJWLyTD", "Tq8DhE6Qso3Phq3qm1l3/9VKV0WdakvV2+0ZKKOBiDCBhTAdBgNVHQ4EFgQUEatT", "bmmWsV87I0JJXHjr+EFUG+IwHwYDVR0jBBgwFoAUEatTbmmWsV87I0JJXHjr+EFU", "G+IwDwYDVR0TAQH/BAUwAwEB/zAyBgNVHREEKzApgglsb2NhbGhvc3SHBH8AAAGH", "ECoBBPjAEH55AAAAAAAAAAGHBFtrpgAwCgYIKoZIzj0EAwIDSAAwRQIhAJZcPG0L", "hrNsdu/Bza0FHk8bWTOji4l7642nkK2QU7mxAiAJSRcNwFKxLu4B7rkky78gQApp", "rqges/DNkDJYhqNA8w==", "-----END CERTIFICATE-----"], "key": ["-----BEGIN PRIVATE KEY-----", "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQggBHazYIFttfoJwa9", "lwqQ2TvfqVulci4hUMg/LkozVTOhRANCAASCGK4AAHea1jtG1Onsms9qh1/4brAJ", "61pUPeM3PX/OQlYvJMNOrwOETpCyjc+GreqbWXf/1UpXRZ1qS9Xb7Rko", "-----END PRIVATE KEY-----"], "serveOnNode": false}]}, "wsSettings": {"path": "/", "host": "pdnc.blackoc.ir"}}}, {"tag": "VLESS WS TLS 2083", "port": 2083, "protocol": "vless", "settings": {"clients": [], "decryption": "mlkem768x25519plus.native.600s.VllROya4-0v5BoToSMRnHqMJEHJKiwRGLMUn8f3erDI", "encryption": "mlkem768x25519plus.native.0rtt.O1sWPTuZ2_Og-z3QvN0NkmODOsLLFogvFez5T6Zkch8"}, "streamSettings": {"network": "ws", "security": "tls", "tlsSettings": {"serverName": "pdnc.blackoc.ir", "alpn": ["http/1.1", "h2", "h3"], "certificates": [{"certificate": ["-----BEGIN CERTIFICATE-----", "MIIBuTCCAV+gAwIBAgIUTn24coKlW7k6Yo7JuKk9zgNBxsMwCgYIKoZIzj0EAwIw", "FzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMB4XDTI2MDcyMjA0NDAyMloXDTM2MDcx", "OTA0NDAyMlowFzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMFkwEwYHKoZIzj0CAQYI", "KoZIzj0DAQcDQgAEghiuAAB3mtY7RtTp7JrPaodf+G6wCetaVD3jNz1/zkJWLyTD", "Tq8DhE6Qso3Phq3qm1l3/9VKV0WdakvV2+0ZKKOBiDCBhTAdBgNVHQ4EFgQUEatT", "bmmWsV87I0JJXHjr+EFUG+IwHwYDVR0jBBgwFoAUEatTbmmWsV87I0JJXHjr+EFU", "G+IwDwYDVR0TAQH/BAUwAwEB/zAyBgNVHREEKzApgglsb2NhbGhvc3SHBH8AAAGH", "ECoBBPjAEH55AAAAAAAAAAGHBFtrpgAwCgYIKoZIzj0EAwIDSAAwRQIhAJZcPG0L", "hrNsdu/Bza0FHk8bWTOji4l7642nkK2QU7mxAiAJSRcNwFKxLu4B7rkky78gQApp", "rqges/DNkDJYhqNA8w==", "-----END CERTIFICATE-----"], "key": ["-----BEGIN PRIVATE KEY-----", "MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQggBHazYIFttfoJwa9", "lwqQ2TvfqVulci4hUMg/LkozVTOhRANCAASCGK4AAHea1jtG1Onsms9qh1/4brAJ", "61pUPeM3PX/OQlYvJMNOrwOETpCyjc+GreqbWXf/1UpXRZ1qS9Xb7Rko", "-----END PRIVATE KEY-----"], "serveOnNode": false}]}, "wsSettings": {"path": "/", "host": "pdnc.blackoc.ir"}}}, {"tag": "VLESS XHTTP REALITY 443", "port": 443, "protocol": "vless", "settings": {"clients": [], "decryption": "mlkem768x25519plus.native.600s.8h48amB4FKxlTHQqpaA6kNeo_inYCle_qwfKThGu8UI", "encryption": "mlkem768x25519plus.native.0rtt.U6kNZ2oZK84zDBmzXW7YpOmGjS-QWNHquJvOk7oQqmo"}, "streamSettings": {"network": "xhttp", "security": "reality", "realitySettings": {"target": "www.sony.com:443", "serverNames": ["www.sony.com"], "privateKey": "WGhxeDmvfPP-YDxhSpGloCTrWhjbR6KPhw7CyMekk3Y", "shortIds": ["d5b63395df9f3be7"], "mldsa65Seed": "LV9Td2XI66Lab0SgxJ0UJKQXlRdXS1ZOnxX7lORlzP4", "spiderX": "/", "fingerprint": "chrome", "publicKey": "HChgs5tWGyepz1bTSILMj-9sCg2T7aNkhAbW1FNiRBs", "mldsa65Verify": "BZkv1TJ-vU3fXWb7Iv0VBYMbyoigzATqfjnu9Uk4IKqkOVKT2W-oEs9M1GPeLMLXc47uH4Ay1d1PzyOA8I04wFNBYhxhoKx-p98M9LmcC4A7BjjZbPRELXQ_0U-31mUclyeWVOa7bXxbqUO0WwjrE7C1Yfs32NvVxdxva9CtiwKGwrRUEla3vgE2mWwfr_QLzHw3bnKOmQQss6DORUnK_xZYgz4crMO7l4XKV4IrymaF5fU7yHYO_iiOAeUTUGywG3qboNbUrdXIePs4iQsOnff3YkbS99yiDty4pARathzbQ8C2j7-GSvYT9iBrlmRhZoYbm6Lqq1ZSPwIGQe7zXnyp5OhyMyLunxdK-hvle-gDDzvf8FnMqYrD_uJMCb26_VYM1HTgtkzKpxeiJMOgB4bqGjLQTW54is-SZ4DkYALjRuyotNvT1BiiFu86j7Mqd5ZcGw9DK34cDVTnubrXQA3cPlAI8hCzBFfxaEhf8rbFYgfePNsb7mRLxJ4g3Fps0bBPjeKGoVnOaAQxjD3vJ18tsvJvphQoqfVl2FerV9igqo9Pg4ZCic0-l8E0UfSFLif4sNPk-iPLIMyZ2jsJnAosyj9FvBYekaSH2XlzrJJgN06ddRX_8qjGdNqr0YBzNaq_6-Uz7FYucy4bSNBVFGg-COzPXKuVUFHLgqOSs4CZaioiGZZOWotb-q14fh5rGjP91s21OH0qO9obu13EyBJ3Az-44bdSBRCnfi8L2JriImbMeGbv_KBKOKnh-SZgxtq3Ca3Zvw4ACOQA_WFiEl36Qd7zF83enT9esHWZkKqkScQ4B13r8Tbq01wtqUCmnX8mXaMi3HvuIlSP-rE3SpgMcq5077FDV879PI3Nt8BxNBF-AgsmiHrUh8AD8caGgrjrEJytX7jq8ElY1JxUGSUDlZ3pEVFDuvN6Feostc1_Gc7wx50nnNUfuAe2V_QPbjfDeRQS_mZvry2WHWuO5Myne7ueApi-vnK7mzIX_feJpW2GiLzLuXumdUMgLLM59ILiCMlkwUxt_8dM72t9l7L1I94TLBAs6VN0MqTRrECmfBEKWPR79rj3UD4O1Rk2p4OxU4HEqrCnrguECuDXr2NYDZQpfPLrM4IfLSk966bWJV2Icksm7hkyL-Zkfk2IokOLaAh9eLwQPJFuGYcNS_9oVPXVaeIpNTr9xHuLMZdqOGHKd7BBI305oIP32D1IoiFe6dIMArcc-AZ0ZjDCkz2pmw-zA2L6gB2KlvNaWqz9fk9afcQwDqjWqAMVxDXMyPXTC-CzIWtYvGTR2ku_Au6wSJRxkK1JrXsXErrNK9_eCVuD_UO-qypB2Od31ujypow8in_WyioAmUD1TueGj6nhVNTW1UQaNGS_8nxv6S6brPhsX1ipwbqPXC9koAqd92QB5R1ccZ742UgHGATbuwgjkL1MTXhGpWjkHAW_hoSo3V33I_zxA4W-emA8AWCHO1E6y_BA5dfgJQ8dJLpgHKecG3mh5QSQM0p2lFYc4YJGTyPqRnLnmLbtoCZU8D5P2w5NJEXAeQnR686X93YBcweDieMzQ0ZMC_7RCTayrZsfM4G3Fx_kKII_fJtg4LOi6e7ad0frbcCEAxFN9AiHtzvHtec99bky5cnU2X-U6nVzaUMRd1tfGeXtLAPmkNpCtW4cOUsClsb9nEWV4nZ68EEKviXBNAZlmXE4M1NT4IF2j4yr4q97NwyvcDEgS4OUp2blqi-g5qnD7cTevFcYW6e06ztQoAejX0gXKzmnF1S9Ti2rILaHaeGMf6_Bn0bg9te5FGfK_jnMTJIvaxs0JSCmsedQyVCF3IbDlyjFu-RC7nZqaAz14PfICfqRczyXzmvVRJ9Phe98YPU-uRmpELYYobsadz_BsLezzTWYaV5ISqGRQZ9jhw-kwxaqwJw-qAlSC7_G6pm4Br0D4q5cZDXAUxhglPCJEkeQiWciy7GbAuvV0DBpuHZ5dtSzzbtA9PXNYDD1yFXbVE20j8fohLUitPD1e5z3FMr1lgfPRkwUjzWy3mUj5iJLFFBOjpShOz0bjfI9e-PB94m_PV8wmXjydy8MkD7TsJ8zSDjv_0haDURykc8nwI1DMrBspghj0ng4q2Y24h2cKIpGCRlXWlSFL3H5C6038_ibRZnnM9UouOWS2j063mBwuz1oqBYeXyEVzK5Ryku5CY8uJeEDDnUBHo56hpwVcummiHTh_NOPxcgPTyPdTAzcvmsnaQCEi1k2GEJ3rceSxowO7SWZZZtqJtlaQk7Ndx8gLrcrEPKdXJBIKV_jsET8m_weXOigwfTgDUMYu58pHcYQlwn61Y0HR43fha02rxcrc7BlOmBN4RgO_NYh9Fs7OvZD6w4ekvGenZ1AHotd4bf6ClRBKsNYeQt3raEO7qpRo0WmkdMM8TumFqiZWRPtBXxrih9t821jd3t6rrKKftnqMHrePiQ7p_4Hn0a7dHVFFAmgFPj-oj0eEOJ-8oy6H3MrSFe3pQWKAL9GvTdf9QyM6LRQEBN38FVongwGo9sArQ4Gc9HcSw4lYVbmldOX-7KMj4CzQB7WH8-8jIoqj2FkPZ51B6AM0DSsSUpsuxc2MtxhnmM"}, "xhttpSettings": {"path": "/pdnc", "mode": "auto", "xPaddingBytes": "100-1000", "xPaddingObfsMode": false}}}], "outbounds": [{"protocol": "freedom", "tag": "DIRECT"}, {"protocol": "blackhole", "tag": "BLOCK"}], "routing": {"rules": [{"ip": ["geoip:private"], "outboundTag": "BLOCK", "type": "field"}]}}			xray
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.groups (id, name, is_disabled) FROM stdin;
1	main	f
\.


--
-- Data for Name: hosts; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.hosts (id, remark, address, port, inbound_tag, sni, host, security, fingerprint, allowinsecure, is_disabled, path, random_user_agent, alpn, use_sni_as_host, priority, http_headers, transport_settings, mux_settings, noise_settings, fragment_settings, status, ech_config_list, vless_route, pinned_peer_cert_sha256, verify_peer_cert_by_name, ech_query_strategy, wireguard_overrides, subscription_templates, final_mask_settings) FROM stdin;
8	VLESS WS TLS 6	104.18.19.193	2087	VLESS WS TLS 2087	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	6	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
9	VLESS WS TLS 7	104.18.155.69	2087	VLESS WS TLS 2087	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	7	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
10	VLESS WS TLS 8	104.27.57.122	2087	VLESS WS TLS 2087	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	8	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
5	VLESS WS TLS  3	www.chatgpt.com	2083	VLESS WS TLS 2083	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	3	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
11	VLESS WS TLS 9	162.159.156.33	2087	VLESS WS TLS 2087	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	9	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
12	VLESS WS TLS  10	104.18.151.3	2083	VLESS WS TLS 2083	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	10	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
6	VLESS WS TLS  4 	www.canva.com	2087	VLESS WS TLS 2087	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	4	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
1	VLESS WS TLS 1	104.18.24.41	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	0	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
2	VLESS WS TLS  2	www.speedtest.net	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	1	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
7	VLESS WS TLS 5	104.25.116.204	2087	VLESS WS TLS 2087	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	5	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
13	VLESS WS TLS  11	104.27.204.219	2083	VLESS WS TLS 2083	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	11	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
14	VLESS WS TLS  12	104.21.114.167	2083	VLESS WS TLS 2083	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	12	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
15	VLESS WS TLS  13	104.18.151.69	2083	VLESS WS TLS 2083	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	13	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
16	VLESS WS TLS  14	104.16.73.211	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	14	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
17	VLESS WS TLS  15	104.18.154.202	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	15	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
18	VLESS WS TLS  16	172.64.155.209	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	16	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
19	VLESS WS TLS  17	104.18.10.167	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	17	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
20	VLESS WS TLS  18	104.18.155.141	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	18	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
21	VLESS WS TLS  19	104.16.75.56	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	19	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
22	VLESS WS TLS  20	104.18.24.41	8443	VLESS WS TLS 8443	pdnc.blackoc.ir	pdnc.blackoc.ir	inbound_default	none	f	f	\N	f	h3,h2,http/1.1	f	20	\N	\N	\N	\N	\N	active	\N	\N	\N		\N	\N	\N	\N
3	VLESS XHTTP REALITY 1	pdnc.blackoc.ir	443	VLESS XHTTP REALITY 443	www.sony.com		inbound_default	none	f	f	pdnc	f	h3,h2,http/1.1	f	2	\N	{"xhttp_settings": {"mode": null, "no_grpc_header": null, "x_padding_bytes": "100", "x_padding_obfs_mode": false, "x_padding_key": null, "x_padding_header": null, "x_padding_placement": null, "x_padding_method": null, "uplink_http_method": null, "session_placement": null, "session_key": null, "seq_placement": null, "seq_key": null, "uplink_data_placement": null, "uplink_data_key": null, "uplink_chunk_size": null, "sc_max_each_post_bytes": "1000", "sc_min_posts_interval_ms": null, "xmux": null, "download_settings": null}, "grpc_settings": null, "kcp_settings": null, "tcp_settings": null, "websocket_settings": null}	\N	\N	\N		\N	\N	\N		\N	\N	\N	\N
23	VLESS XHTTP REALITY 2	pdnc.blackoc.ir	443	VLESS XHTTP REALITY 443	www.dl.google.com		inbound_default	none	f	f	pdnc	f	h3,h2,http/1.1	f	21	\N	{"xhttp_settings": {"mode": null, "no_grpc_header": null, "x_padding_bytes": "100", "x_padding_obfs_mode": false, "x_padding_key": null, "x_padding_header": null, "x_padding_placement": null, "x_padding_method": null, "uplink_http_method": null, "session_placement": null, "session_key": null, "seq_placement": null, "seq_key": null, "uplink_data_placement": null, "uplink_data_key": null, "uplink_chunk_size": null, "sc_max_each_post_bytes": "1000", "sc_min_posts_interval_ms": null, "xmux": null, "download_settings": null}, "grpc_settings": null, "kcp_settings": null, "tcp_settings": null, "websocket_settings": null}	\N	\N	\N		\N	\N	\N		\N	\N	\N	\N
24	VLESS XHTTP REALITY 3	pdnc.blackoc.ir	443	VLESS XHTTP REALITY 443	www.cloudflare.com		inbound_default	none	f	f	pdnc	f	h3,h2,http/1.1	f	22	\N	{"xhttp_settings": {"mode": null, "no_grpc_header": null, "x_padding_bytes": "100", "x_padding_obfs_mode": false, "x_padding_key": null, "x_padding_header": null, "x_padding_placement": null, "x_padding_method": null, "uplink_http_method": null, "session_placement": null, "session_key": null, "seq_placement": null, "seq_key": null, "uplink_data_placement": null, "uplink_data_key": null, "uplink_chunk_size": null, "sc_max_each_post_bytes": "1000", "sc_min_posts_interval_ms": null, "xmux": null, "download_settings": null}, "grpc_settings": null, "kcp_settings": null, "tcp_settings": null, "websocket_settings": null}	\N	\N	\N		\N	\N	\N		\N	\N	\N	\N
\.


--
-- Data for Name: inbounds; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.inbounds (id, tag) FROM stdin;
1	Shadowsocks TCP
35	VLESS WS TLS 8443
60	VLESS WS TLS 2087
64	VLESS WS TLS 2083
65	VLESS XHTTP REALITY 443
\.


--
-- Data for Name: inbounds_groups_association; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.inbounds_groups_association (inbound_id, group_id) FROM stdin;
35	1
65	1
64	1
60	1
\.


--
-- Data for Name: jwt; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.jwt (id, secret_key) FROM stdin;
1	542440f51f31a234ec66644da16bfad41f8317b24492e684c576676c0d9362fd
\.


--
-- Data for Name: next_plans; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.next_plans (id, user_id, data_limit, expire, add_remaining_traffic, user_template_id) FROM stdin;
\.


--
-- Data for Name: node_stats; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.node_stats (id, created_at, node_id, mem_total, mem_used, cpu_cores, cpu_usage, incoming_bandwidth_speed, outgoing_bandwidth_speed) FROM stdin;
\.


--
-- Data for Name: node_usage_reset_logs; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.node_usage_reset_logs (id, created_at, node_id, uplink, downlink) FROM stdin;
\.


--
-- Data for Name: node_usages; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.node_usages (id, created_at, node_id, uplink, downlink) FROM stdin;
110	2026-07-22 07:20:00+00	1	25388	45145
1	2026-07-22 05:20:00+00	1	13848	24624
608	2026-07-22 13:40:00+00	1	20772	36933
55	2026-07-22 06:20:00+00	1	27342	47555
288	2026-07-22 10:30:00+00	1	636648	1884229
239	2026-07-22 09:50:00+00	1	23080	41046
178	2026-07-22 08:40:00+00	1	27696	49244
5	2026-07-22 05:30:00+00	1	33558	56462
120	2026-07-22 07:30:00+00	1	27696	49247
65	2026-07-22 06:30:00+00	1	25657	42953
16	2026-07-22 05:40:00+00	1	27611	45358
348	2026-07-22 11:00:00+00	1	1787849	3247333
129	2026-07-22 07:40:00+00	1	19087	32337
188	2026-07-22 08:50:00+00	1	16156	28727
539	2026-07-22 12:50:00+00	1	212362	1946989
484	2026-07-22 12:10:00+00	1	249653	406335
75	2026-07-22 06:40:00+00	1	36843	61775
24	2026-07-22 05:50:00+00	1	42082	69488
249	2026-07-22 10:00:00+00	1	51328	72034
136	2026-07-22 07:50:00+00	1	25388	45144
87	2026-07-22 06:50:00+00	1	34804	55479
36	2026-07-22 06:00:00+00	1	31958	55758
194	2026-07-22 09:00:00+00	1	23080	41044
663	2026-07-22 14:50:00+00	1	20772	36936
47	2026-07-22 06:10:00+00	1	18464	32837
145	2026-07-22 08:00:00+00	1	23080	41041
494	2026-07-22 12:20:00+00	1	25388	45146
95	2026-07-22 07:00:00+00	1	33912	58165
202	2026-07-22 09:10:00+00	1	27696	49248
106	2026-07-22 07:10:00+00	1	11540	20517
614	2026-07-22 13:50:00+00	1	27696	49253
257	2026-07-22 10:10:00+00	1	32312	57453
155	2026-07-22 08:10:00+00	1	20772	36938
424	2026-07-22 11:40:00+00	1	515482	927165
211	2026-07-22 09:20:00+00	1	20772	36940
308	2026-07-22 10:40:00+00	1	1153937	2221660
163	2026-07-22 08:20:00+00	1	30004	53351
754	2026-07-22 16:40:00+00	1	20772	36935
368	2026-07-22 11:10:00+00	1	571178	1306340
713	2026-07-22 15:50:00+00	1	23080	41041
171	2026-07-22 08:30:00+00	1	20772	36937
218	2026-07-22 09:30:00+00	1	31250	52360
670	2026-07-22 15:00:00+00	1	25388	45144
622	2026-07-22 14:00:00+00	1	18464	32828
557	2026-07-22 13:00:00+00	1	306387	3536491
268	2026-07-22 10:20:00+00	1	339930	1857499
228	2026-07-22 09:40:00+00	1	34535	57668
761	2026-07-22 16:50:00+00	1	6924	12314
502	2026-07-22 12:30:00+00	1	1298613	5489167
328	2026-07-22 10:50:00+00	1	1306839	8668781
387	2026-07-22 11:20:00+00	1	326283	1542895
721	2026-07-22 16:00:00+00	1	20772	36936
444	2026-07-22 11:50:00+00	1	291357	294702
679	2026-07-22 15:10:00+00	1	18464	32829
629	2026-07-22 14:10:00+00	1	30004	53350
575	2026-07-22 13:10:00+00	1	379171	4682219
639	2026-07-22 14:20:00+00	1	53190	112750
729	2026-07-22 16:10:00+00	1	13848	24622
404	2026-07-22 11:30:00+00	1	486837	1043497
520	2026-07-22 12:40:00+00	1	364954	7831272
687	2026-07-22 15:20:00+00	1	30004	53355
464	2026-07-22 12:00:00+00	1	240403	340019
588	2026-07-22 13:20:00+00	1	349748	1920398
647	2026-07-22 14:30:00+00	1	20772	36935
601	2026-07-22 13:30:00+00	1	18464	32832
697	2026-07-22 15:30:00+00	1	20772	36932
655	2026-07-22 14:40:00+00	1	23080	41041
735	2026-07-22 16:20:00+00	1	32312	57461
704	2026-07-22 15:40:00+00	1	58292	122376
745	2026-07-22 16:30:00+00	1	27696	49244
\.


--
-- Data for Name: node_user_usages; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.node_user_usages (id, created_at, user_id, node_id, used_traffic) FROM stdin;
673	2026-07-22 13:10:00+00	1	1	4914015
1	2026-07-22 05:30:00+00	1	1	13080
4	2026-07-22 05:40:00+00	1	1	15260
514	2026-07-22 12:10:00+00	1	1	564662
9	2026-07-22 05:50:00+00	1	1	21800
13	2026-07-22 06:00:00+00	1	1	4360
14	2026-07-22 06:20:00+00	1	1	4360
15	2026-07-22 06:30:00+00	1	1	10900
18	2026-07-22 06:40:00+00	1	1	15260
608	2026-07-22 12:50:00+00	1	1	2128646
21	2026-07-22 06:50:00+00	1	1	26160
26	2026-07-22 07:00:00+00	1	1	8720
28	2026-07-22 07:40:00+00	1	1	6540
29	2026-07-22 09:30:00+00	1	1	13080
31	2026-07-22 09:40:00+00	1	1	15260
33	2026-07-22 10:00:00+00	1	1	78480
35	2026-07-22 10:10:00+00	1	1	110146
323	2026-07-22 11:10:00+00	1	1	1776233
380	2026-07-22 11:30:00+00	1	1	1410468
37	2026-07-22 10:20:00+00	1	1	2153157
89	2026-07-22 10:30:00+00	1	1	2341503
147	2026-07-22 10:40:00+00	1	1	3464768
455	2026-07-22 11:50:00+00	1	1	514935
206	2026-07-22 10:50:00+00	1	1	9792970
691	2026-07-22 13:20:00+00	1	1	2199616
263	2026-07-22 11:00:00+00	1	1	5060816
357	2026-07-22 11:20:00+00	1	1	1811375
712	2026-07-22 14:20:00+00	1	1	101819
716	2026-07-22 15:40:00+00	1	1	110140
570	2026-07-22 12:40:00+00	1	1	8075589
641	2026-07-22 13:00:00+00	1	1	3832722
417	2026-07-22 11:40:00+00	1	1	1339329
481	2026-07-22 12:00:00+00	1	1	556336
522	2026-07-22 12:30:00+00	1	1	6769670
\.


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.nodes (id, name, address, port, status, last_status_change, message, created_at, uplink, downlink, xray_version, usage_coefficient, node_version, connection_type, server_ca, keep_alive, core_config_id, api_key, data_limit, data_limit_reset_strategy, reset_time, default_timeout, internal_timeout, api_port, proxy_url) FROM stdin;
1	main	127.0.0.1	62050	connected	2026-07-22 09:42:03.481821+00		2026-07-22 04:42:43.003875+00	12192268	51571059	26.3.27	1	0.5.3	grpc	-----BEGIN CERTIFICATE-----\nMIIBuTCCAV+gAwIBAgIUTn24coKlW7k6Yo7JuKk9zgNBxsMwCgYIKoZIzj0EAwIw\nFzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMB4XDTI2MDcyMjA0NDAyMloXDTM2MDcx\nOTA0NDAyMlowFzEVMBMGA1UEAwwMOTEuMTA3LjE2Ni4wMFkwEwYHKoZIzj0CAQYI\nKoZIzj0DAQcDQgAEghiuAAB3mtY7RtTp7JrPaodf+G6wCetaVD3jNz1/zkJWLyTD\nTq8DhE6Qso3Phq3qm1l3/9VKV0WdakvV2+0ZKKOBiDCBhTAdBgNVHQ4EFgQUEatT\nbmmWsV87I0JJXHjr+EFUG+IwHwYDVR0jBBgwFoAUEatTbmmWsV87I0JJXHjr+EFU\nG+IwDwYDVR0TAQH/BAUwAwEB/zAyBgNVHREEKzApgglsb2NhbGhvc3SHBH8AAAGH\nECoBBPjAEH55AAAAAAAAAAGHBFtrpgAwCgYIKoZIzj0EAwIDSAAwRQIhAJZcPG0L\nhrNsdu/Bza0FHk8bWTOji4l7642nkK2QU7mxAiAJSRcNwFKxLu4B7rkky78gQApp\nrqges/DNkDJYhqNA8w==\n-----END CERTIFICATE-----	60	1	64ddc9dd-f9ae-4ee0-b569-cf5e7d24b199	0	no_reset	-1	10	15	62051	\N
\.


--
-- Data for Name: notification_reminders; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.notification_reminders (id, user_id, type, expires_at, created_at, threshold) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.settings (id, telegram, webhook, notification_settings, notification_enable, subscription, general, hwid) FROM stdin;
1	{"enable": false, "token": null, "webhook_url": null, "webhook_secret": null, "proxy_url": null}	{"enable": false, "webhooks": [], "days_left": [3], "usage_percent": [80], "timeout": 180, "recurrent": 3, "proxy_url": null}	{"notify_telegram": false, "notify_discord": false, "telegram_api_token": null, "telegram_chat_id": null, "telegram_topic_id": null, "discord_webhook_url": null, "proxy_url": null, "max_retries": 3}	{"admin": {"create": true, "modify": true, "delete": true, "reset_usage": true, "login": true}, "core": {"create": true, "modify": true, "delete": true}, "group": {"create": true, "modify": true, "delete": true}, "host": {"create": true, "modify": true, "delete": true, "modify_hosts": true}, "node": {"create": true, "modify": true, "delete": true, "connect": true, "error": true}, "user": {"create": true, "modify": true, "delete": true, "status_change": true, "reset_data_usage": true, "data_reset_by_next": true, "subscription_revoked": true}, "user_template": {"create": true, "modify": true, "delete": true}, "days_left": true, "percentage_reached": true}	{"url_prefix": "", "update_interval": "12", "support_url": "https://t.me/", "profile_title": "Subscription", "host_status_filter": true, "randomize_order": false, "rules": [{"pattern": "^(?:FlClashX?|Flowvy|[Cc]lash(?:-(?:[Vv]erge|nyanpasu)|X [Mm]eta|-?[Mm]eta)|[Kk]oala-[Cc]lash|[Mm](?:urge|ihomo)|prizrak-box|clash\\\\.meta)", "target": "clash_meta"}, {"pattern": "^([Cc]lash|[Ss]tash)", "target": "clash"}, {"pattern": "^(SFA|SFI|SFM|SFT|[Kk]aring|[Hh]iddify[Nn]ext)|.*[Ss]ing[\\\\-b]?ox.*", "target": "sing_box"}, {"pattern": "^(SS|SSR|SSD|SSS|Outline|Shadowsocks|SSconf)", "target": "outline"}, {"pattern": "^[Ii]n[Hh]ive", "target": "xray"}, {"pattern": "^.*", "target": "links_base64"}], "manual_sub_request": {"links": true, "links_base64": true, "xray": true, "sing_box": true, "clash": true, "clash_meta": true, "outline": true}}	{"default_flow": "", "default_method": "chacha20-ietf-poly1305"}	{}
\.


--
-- Data for Name: system; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.system (id, uplink, downlink) FROM stdin;
1	12192268	51571059
\.


--
-- Data for Name: temp_keys; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.temp_keys (key, action, expires_at, used_at, used_by_ip) FROM stdin;
b5bc1482-10ce-4cf7-978f-20db3aadd2fa	create_owner	2026-07-22 04:46:05.807572+00	2026-07-22 04:41:29.441364+00	185.145.187.131
\.


--
-- Data for Name: template_group_association; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.template_group_association (user_template_id, group_id) FROM stdin;
\.


--
-- Data for Name: user_hwids; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.user_hwids (id, user_id, hwid, device_os, os_version, device_model, created_at, last_used_at) FROM stdin;
1	1	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A	iOS	26.5.2	iPhone14,3	2026-07-22 10:19:46.982875+00	2026-07-22 15:40:50.234981+00
\.


--
-- Data for Name: user_subscription_updates; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.user_subscription_updates (id, user_id, created_at, user_agent, ip, hwid) FROM stdin;
40	1	2026-07-22 09:43:10.436943+00	v2rayN/7.22.7	185.145.187.131	\N
41	1	2026-07-22 10:06:18.707005+00	v2rayN/7.22.7	185.145.187.131	\N
42	1	2026-07-22 10:07:34.326178+00	v2rayN/7.22.7	185.145.187.131	\N
43	1	2026-07-22 10:19:46.611444+00	V2Box 10.1.6/iOS 26.5.2	185.145.187.131	\N
44	1	2026-07-22 10:19:46.989164+00	V2Box 10.1.6/iOS 26.5.2	185.145.187.131	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A
45	1	2026-07-22 10:59:00.78592+00	V2Box 10.1.6/iOS 26.5.2	185.145.187.131	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A
46	1	2026-07-22 12:32:08.877727+00	V2Box 10.1.6/iOS 26.5.2	5.216.89.223	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A
47	1	2026-07-22 13:12:53.522048+00	V2Box 10.1.6/iOS 26.5.2	5.213.166.135	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A
48	1	2026-07-22 14:25:31.930392+00	V2Box 10.1.6/iOS 26.5.2	37.156.167.149	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A
49	1	2026-07-22 15:40:50.241209+00	V2Box 10.1.6/iOS 26.5.2	37.156.167.149	0F20CAA8-4E21-4BDF-9A6E-50C9FD10472A
\.


--
-- Data for Name: user_templates; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.user_templates (id, name, data_limit, expire_duration, username_prefix, username_suffix, extra_settings, status, reset_usages, on_hold_timeout, data_limit_reset_strategy, is_disabled, hwid_limit) FROM stdin;
\.


--
-- Data for Name: user_usage_logs; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.user_usage_logs (id, user_id, used_traffic_at_reset, reset_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.users (id, username, status, used_traffic, data_limit, created_at, admin_id, data_limit_reset_strategy, sub_revoked_at, note, online_at, edit_at, on_hold_timeout, on_hold_expire_duration, auto_delete_in_days, last_status_change, expire, proxy_settings, hwid_limit) FROM stdin;
1	test	active	59262175	\N	2026-07-22 04:50:06.358466+00	1	no_reset	\N	\N	2026-07-22 15:40:59.641991+00	2026-07-22 05:26:48.0624+00	\N	\N	\N	\N	\N	{"vmess": {"id": "88b17adc-22a7-4bca-a67b-5c9033016600"}, "vless": {"id": "a4336adf-21df-41d1-8436-fa9cc9267a93"}, "trojan": {"password": "GNSk6-fqddXmPf-Rhkjtn66nPdl10ydT"}, "shadowsocks": {"password": "Y8tCpAL_YnWrBe-5oO5cSvrl_qbY3snV", "method": "chacha20-ietf-poly1305"}, "wireguard": {"private_key": "hqgL023QrIdRdY4HAoDr5II8o6CQnXMlqsjD5HeDCgs=", "public_key": "fH62RGFB+w1pMkIBn1DAGpq6FBkcHOB/i4iSc0quSQs=", "peer_ips": []}, "hysteria": {"auth": "IZaOrjOpvCaF22KwHMOh76Eq2m2KPS9I"}}	\N
\.


--
-- Data for Name: users_groups_association; Type: TABLE DATA; Schema: public; Owner: pasarguard
--

COPY public.users_groups_association (user_id, groups_id) FROM stdin;
1	1
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: pasarguard
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1000, false);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: pasarguard
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: pasarguard
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: pasarguard
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 1, false);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: pasarguard
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: pasarguard
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 1, false);


--
-- Name: admin_notification_reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.admin_notification_reminders_id_seq', 1, false);


--
-- Name: admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.admin_roles_id_seq', 3, true);


--
-- Name: admin_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.admin_usage_logs_id_seq', 1, false);


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: client_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.client_templates_id_seq', 5, true);


--
-- Name: core_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.core_configs_id_seq', 1, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, true);


--
-- Name: hosts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.hosts_id_seq', 24, true);


--
-- Name: inbounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.inbounds_id_seq', 519, true);


--
-- Name: jwt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.jwt_id_seq', 1, false);


--
-- Name: next_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.next_plans_id_seq', 1, false);


--
-- Name: node_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.node_stats_id_seq', 1, false);


--
-- Name: node_usage_reset_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.node_usage_reset_logs_id_seq', 1, false);


--
-- Name: node_usages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.node_usages_id_seq', 763, true);


--
-- Name: node_user_usages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.node_user_usages_id_seq', 717, true);


--
-- Name: nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.nodes_id_seq', 1, true);


--
-- Name: notification_reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.notification_reminders_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, true);


--
-- Name: system_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.system_id_seq', 1, false);


--
-- Name: user_hwids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.user_hwids_id_seq', 6, true);


--
-- Name: user_subscription_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.user_subscription_updates_id_seq', 49, true);


--
-- Name: user_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.user_templates_id_seq', 1, false);


--
-- Name: user_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.user_usage_logs_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pasarguard
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: admin_notification_reminders pk_admin_notification_reminders; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_notification_reminders
    ADD CONSTRAINT pk_admin_notification_reminders PRIMARY KEY (id);


--
-- Name: admin_roles pk_admin_roles; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT pk_admin_roles PRIMARY KEY (id);


--
-- Name: admin_usage_logs pk_admin_usage_logs; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_usage_logs
    ADD CONSTRAINT pk_admin_usage_logs PRIMARY KEY (id);


--
-- Name: admins pk_admins; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT pk_admins PRIMARY KEY (id);


--
-- Name: api_keys pk_api_keys; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT pk_api_keys PRIMARY KEY (id);


--
-- Name: client_templates pk_client_templates; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.client_templates
    ADD CONSTRAINT pk_client_templates PRIMARY KEY (id);


--
-- Name: core_configs pk_core_configs; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.core_configs
    ADD CONSTRAINT pk_core_configs PRIMARY KEY (id);


--
-- Name: groups pk_groups; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT pk_groups PRIMARY KEY (id);


--
-- Name: hosts pk_hosts; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.hosts
    ADD CONSTRAINT pk_hosts PRIMARY KEY (id);


--
-- Name: inbounds pk_inbounds; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.inbounds
    ADD CONSTRAINT pk_inbounds PRIMARY KEY (id);


--
-- Name: inbounds_groups_association pk_inbounds_groups_association; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.inbounds_groups_association
    ADD CONSTRAINT pk_inbounds_groups_association PRIMARY KEY (inbound_id, group_id);


--
-- Name: jwt pk_jwt; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.jwt
    ADD CONSTRAINT pk_jwt PRIMARY KEY (id);


--
-- Name: next_plans pk_next_plans; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.next_plans
    ADD CONSTRAINT pk_next_plans PRIMARY KEY (id);


--
-- Name: node_stats pk_node_stats; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_stats
    ADD CONSTRAINT pk_node_stats PRIMARY KEY (id);


--
-- Name: node_usage_reset_logs pk_node_usage_reset_logs; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usage_reset_logs
    ADD CONSTRAINT pk_node_usage_reset_logs PRIMARY KEY (id);


--
-- Name: node_usages pk_node_usages; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usages
    ADD CONSTRAINT pk_node_usages PRIMARY KEY (id);


--
-- Name: node_user_usages pk_node_user_usages; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_user_usages
    ADD CONSTRAINT pk_node_user_usages PRIMARY KEY (id);


--
-- Name: nodes pk_nodes; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT pk_nodes PRIMARY KEY (id);


--
-- Name: notification_reminders pk_notification_reminders; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.notification_reminders
    ADD CONSTRAINT pk_notification_reminders PRIMARY KEY (id);


--
-- Name: settings pk_settings; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT pk_settings PRIMARY KEY (id);


--
-- Name: system pk_system; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.system
    ADD CONSTRAINT pk_system PRIMARY KEY (id);


--
-- Name: temp_keys pk_temp_keys; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.temp_keys
    ADD CONSTRAINT pk_temp_keys PRIMARY KEY (key);


--
-- Name: user_hwids pk_user_hwids; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_hwids
    ADD CONSTRAINT pk_user_hwids PRIMARY KEY (id);


--
-- Name: user_subscription_updates pk_user_subscription_updates; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_subscription_updates
    ADD CONSTRAINT pk_user_subscription_updates PRIMARY KEY (id);


--
-- Name: user_templates pk_user_templates; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_templates
    ADD CONSTRAINT pk_user_templates PRIMARY KEY (id);


--
-- Name: user_usage_logs pk_user_usage_logs; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_usage_logs
    ADD CONSTRAINT pk_user_usage_logs PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: users_groups_association pk_users_groups_association; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.users_groups_association
    ADD CONSTRAINT pk_users_groups_association PRIMARY KEY (user_id, groups_id);


--
-- Name: admin_roles uq_admin_roles_name; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT uq_admin_roles_name UNIQUE (name);


--
-- Name: api_keys uq_api_keys_admin_id; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT uq_api_keys_admin_id UNIQUE (admin_id, name);


--
-- Name: api_keys uq_api_keys_key_hash; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT uq_api_keys_key_hash UNIQUE (key_hash);


--
-- Name: client_templates uq_client_templates_template_type; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.client_templates
    ADD CONSTRAINT uq_client_templates_template_type UNIQUE (template_type, name);


--
-- Name: node_usages uq_node_usages_created_at; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usages
    ADD CONSTRAINT uq_node_usages_created_at UNIQUE (created_at, node_id);


--
-- Name: node_user_usages uq_node_user_usages_created_at; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_user_usages
    ADD CONSTRAINT uq_node_user_usages_created_at UNIQUE (created_at, user_id, node_id);


--
-- Name: nodes uq_nodes_name; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT uq_nodes_name UNIQUE (name);


--
-- Name: user_hwids uq_user_hwids_user_id; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_hwids
    ADD CONSTRAINT uq_user_hwids_user_id UNIQUE (user_id, hwid);


--
-- Name: user_templates uq_user_templates_name; Type: CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_templates
    ADD CONSTRAINT uq_user_templates_name UNIQUE (name);


--
-- Name: idx_user_subscription_updates_user_id; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX idx_user_subscription_updates_user_id ON public.user_subscription_updates USING btree (user_id);


--
-- Name: idx_users_admin_created; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX idx_users_admin_created ON public.users USING btree (admin_id, created_at);


--
-- Name: idx_users_admin_online; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX idx_users_admin_online ON public.users USING btree (admin_id, online_at);


--
-- Name: idx_users_admin_status; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX idx_users_admin_status ON public.users USING btree (admin_id, status);


--
-- Name: ix_admin_notification_reminders_admin_id_type; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_admin_notification_reminders_admin_id_type ON public.admin_notification_reminders USING btree (admin_id, type);


--
-- Name: ix_admins_username; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE UNIQUE INDEX ix_admins_username ON public.admins USING btree (username);


--
-- Name: ix_api_keys_admin_id; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_api_keys_admin_id ON public.api_keys USING btree (admin_id);


--
-- Name: ix_api_keys_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_api_keys_created_at ON public.api_keys USING btree (created_at);


--
-- Name: ix_api_keys_expire_date; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_api_keys_expire_date ON public.api_keys USING btree (expire_date);


--
-- Name: ix_client_templates_template_type; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_client_templates_template_type ON public.client_templates USING btree (template_type);


--
-- Name: ix_inbounds_tag; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE UNIQUE INDEX ix_inbounds_tag ON public.inbounds USING btree (tag);


--
-- Name: ix_next_plans_user_template_id; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_next_plans_user_template_id ON public.next_plans USING btree (user_template_id);


--
-- Name: ix_node_usage_reset_logs_node_id_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_node_usage_reset_logs_node_id_created_at ON public.node_usage_reset_logs USING btree (node_id, created_at);


--
-- Name: ix_node_usages_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_node_usages_created_at ON public.node_usages USING btree (created_at);


--
-- Name: ix_node_user_usages_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_node_user_usages_created_at ON public.node_user_usages USING btree (created_at);


--
-- Name: ix_node_user_usages_node_id_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_node_user_usages_node_id_created_at ON public.node_user_usages USING btree (node_id, created_at);


--
-- Name: ix_node_user_usages_user_id_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_node_user_usages_user_id_created_at ON public.node_user_usages USING btree (user_id, created_at);


--
-- Name: ix_user_hwids_created_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_user_hwids_created_at ON public.user_hwids USING btree (created_at);


--
-- Name: ix_user_hwids_hwid; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_user_hwids_hwid ON public.user_hwids USING btree (hwid);


--
-- Name: ix_user_hwids_last_used_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_user_hwids_last_used_at ON public.user_hwids USING btree (last_used_at);


--
-- Name: ix_user_hwids_user_id; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_user_hwids_user_id ON public.user_hwids USING btree (user_id);


--
-- Name: ix_user_usage_logs_user_id_reset_at; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE INDEX ix_user_usage_logs_user_id_reset_at ON public.user_usage_logs USING btree (user_id, reset_at);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: pasarguard
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: admin_notification_reminders fk_admin_notification_reminders_admin_id_admins; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_notification_reminders
    ADD CONSTRAINT fk_admin_notification_reminders_admin_id_admins FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: admin_usage_logs fk_admin_usage_logs_admin_id_admins; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admin_usage_logs
    ADD CONSTRAINT fk_admin_usage_logs_admin_id_admins FOREIGN KEY (admin_id) REFERENCES public.admins(id);


--
-- Name: admins fk_admins_role_id_admin_roles; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT fk_admins_role_id_admin_roles FOREIGN KEY (role_id) REFERENCES public.admin_roles(id);


--
-- Name: api_keys fk_api_keys_admin_id_admins; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT fk_api_keys_admin_id_admins FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: hosts fk_hosts_inbound_tag_inbounds; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.hosts
    ADD CONSTRAINT fk_hosts_inbound_tag_inbounds FOREIGN KEY (inbound_tag) REFERENCES public.inbounds(tag) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inbounds_groups_association fk_inbounds_groups_association_group_id_groups; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.inbounds_groups_association
    ADD CONSTRAINT fk_inbounds_groups_association_group_id_groups FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: inbounds_groups_association fk_inbounds_groups_association_inbound_id_inbounds; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.inbounds_groups_association
    ADD CONSTRAINT fk_inbounds_groups_association_inbound_id_inbounds FOREIGN KEY (inbound_id) REFERENCES public.inbounds(id);


--
-- Name: next_plans fk_next_plans_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.next_plans
    ADD CONSTRAINT fk_next_plans_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: next_plans fk_next_plans_user_template_id_user_templates; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.next_plans
    ADD CONSTRAINT fk_next_plans_user_template_id_user_templates FOREIGN KEY (user_template_id) REFERENCES public.user_templates(id) ON DELETE SET NULL;


--
-- Name: node_stats fk_node_stats_node_id_nodes; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_stats
    ADD CONSTRAINT fk_node_stats_node_id_nodes FOREIGN KEY (node_id) REFERENCES public.nodes(id);


--
-- Name: node_usage_reset_logs fk_node_usage_reset_logs_node_id_nodes; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usage_reset_logs
    ADD CONSTRAINT fk_node_usage_reset_logs_node_id_nodes FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: node_usages fk_node_usages_node_id_nodes; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_usages
    ADD CONSTRAINT fk_node_usages_node_id_nodes FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: node_user_usages fk_node_user_usages_node_id_nodes; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_user_usages
    ADD CONSTRAINT fk_node_user_usages_node_id_nodes FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- Name: node_user_usages fk_node_user_usages_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.node_user_usages
    ADD CONSTRAINT fk_node_user_usages_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_reminders fk_notification_reminders_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.notification_reminders
    ADD CONSTRAINT fk_notification_reminders_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: template_group_association fk_template_group_association_group_id_groups; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.template_group_association
    ADD CONSTRAINT fk_template_group_association_group_id_groups FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: template_group_association fk_template_group_association_user_template_id_user_templates; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.template_group_association
    ADD CONSTRAINT fk_template_group_association_user_template_id_user_templates FOREIGN KEY (user_template_id) REFERENCES public.user_templates(id);


--
-- Name: user_hwids fk_user_hwids_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_hwids
    ADD CONSTRAINT fk_user_hwids_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_subscription_updates fk_user_subscription_updates_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_subscription_updates
    ADD CONSTRAINT fk_user_subscription_updates_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_usage_logs fk_user_usage_logs_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.user_usage_logs
    ADD CONSTRAINT fk_user_usage_logs_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users fk_users_admin_id_admins; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_admin_id_admins FOREIGN KEY (admin_id) REFERENCES public.admins(id);


--
-- Name: users_groups_association fk_users_groups_association_groups_id_groups; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.users_groups_association
    ADD CONSTRAINT fk_users_groups_association_groups_id_groups FOREIGN KEY (groups_id) REFERENCES public.groups(id);


--
-- Name: users_groups_association fk_users_groups_association_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.users_groups_association
    ADD CONSTRAINT fk_users_groups_association_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: nodes nodes_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: pasarguard
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_ibfk_1 FOREIGN KEY (core_config_id) REFERENCES public.core_configs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict WJEinpc3hsNFR3GuQBsXFfP14aUCuqT1BjYF6fTfqsR6p6glAJfRJe6IAZoaEDc

