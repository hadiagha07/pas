--
-- PostgreSQL database cluster dump
--

\restrict fABTJZQL2nTBCD2ZfrnhFAgxDj3QPdAilwCZCkdMWi70a9sOo6yBkiewff6mRR1

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE pasarguard;
ALTER ROLE pasarguard WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:2RfUdrJiO9O1hmytA3QVOw==$9NArbJIOTXoSzqHiFSdlq9lLw5YNd1MGn3+CW0udzlc=:+ijsuUxCSpAF8r73Swq1qNPhNTA1X8JNyFYyJQr9gh0=';

--
-- User Configurations
--








\unrestrict fABTJZQL2nTBCD2ZfrnhFAgxDj3QPdAilwCZCkdMWi70a9sOo6yBkiewff6mRR1

--
-- PostgreSQL database cluster dump complete
--

